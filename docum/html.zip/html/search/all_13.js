var searchData=
[
  ['window_0',['window',['../class_game.html#ad0fb4d8653dcf289fd6573cf5ba0f3d1',1,'Game::window'],['../class_menu.html#a56a1907bf19e3ccdfbd31189c71fc18c',1,'Menu::window']]],
  ['with_20ai_20uml_20diagrams_1',['Checkers Game with AI UML Diagrams',['../index.html',1,'']]],
  ['works_2',['How It Works',['../index.html#autotoc_md10',1,'']]]
];

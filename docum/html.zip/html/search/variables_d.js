var searchData=
[
  ['y_0',['y',['../class_piece.html#a97d61c9e42873e2274620c91178e879b',1,'Piece']]]
];

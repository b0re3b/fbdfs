var searchData=
[
  ['logic_2ecpp_0',['logic.cpp',['../logic_8cpp.html',1,'']]],
  ['logic_2eh_1',['logic.h',['../logic_8h.html',1,'']]]
];

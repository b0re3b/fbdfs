var searchData=
[
  ['logic_0',['logic',['../classlogic.html',1,'']]],
  ['logic_2ecpp_1',['logic.cpp',['../logic_8cpp.html',1,'']]],
  ['logic_2eh_2',['logic.h',['../logic_8h.html',1,'']]]
];

var searchData=
[
  ['package_20diagram_0',['Package diagram',['../index.html#autotoc_md20',1,'']]],
  ['piece_1',['Piece',['../class_piece.html',1,'Piece'],['../class_piece.html#ac57de5803bbad829b143bc7268267dc1',1,'Piece::Piece()'],['../index.html#autotoc_md4',1,'Piece']]],
  ['piece_2ecpp_2',['piece.cpp',['../piece_8cpp.html',1,'']]],
  ['piece_2eh_3',['piece.h',['../piece_8h.html',1,'']]],
  ['pieces_4',['pieces',['../class_board.html#a390535e7cc8ea9aa2f994161476dff5a',1,'Board']]],
  ['player_5',['Player',['../class_player.html',1,'Player'],['../class_player.html#aaae88a768d53a2c960f973b7aefff5b4',1,'Player::Player(const sf::Color color)'],['../class_player.html#a9ceaaf5c4f494db523411bdcaf781189',1,'Player::Player(sf::Color color, PlayerType type)'],['../index.html#autotoc_md5',1,'Player']]],
  ['player_2ecpp_6',['player.cpp',['../player_8cpp.html',1,'']]],
  ['player_2eh_7',['player.h',['../player_8h.html',1,'']]],
  ['playertest_8',['PlayerTest',['../class_player_test.html',1,'']]],
  ['playertype_9',['PlayerType',['../class_player.html#a97dc3c423902370176605121e8f68415',1,'Player']]]
];

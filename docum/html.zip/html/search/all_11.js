var searchData=
[
  ['uml_0',['UML',['../index.html#autotoc_md13',1,'']]],
  ['uml_20diagrams_1',['Checkers Game with AI UML Diagrams',['../index.html',1,'']]],
  ['use_20case_2',['Use case',['../index.html#autotoc_md14',1,'']]]
];

var searchData=
[
  ['endgame_0',['endgame',['../class_board.html#a1a9724c2e538c140e31c3afdba27f761',1,'Board']]],
  ['evaluateboard_1',['evaluateBoard',['../class_board.html#a3faffd4339880c193735bec8f04e4c70',1,'Board']]]
];

var searchData=
[
  ['validarity_0',['validarity',['../class_board.html#ac507952205438609f027d6c49ed78add',1,'Board']]]
];

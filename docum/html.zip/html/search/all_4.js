var searchData=
[
  ['endgame_0',['endgame',['../class_board.html#a1a9724c2e538c140e31c3afdba27f761',1,'Board']]],
  ['endx_1',['endX',['../class_move.html#a1c557dde425b7624f0ca7e6e7f33baa5',1,'Move']]],
  ['endy_2',['endY',['../class_move.html#a1223cbd38258e9b08f977ea6670f1357',1,'Move']]],
  ['evaluateboard_3',['evaluateBoard',['../class_board.html#a3faffd4339880c193735bec8f04e4c70',1,'Board']]]
];

var searchData=
[
  ['numberofmoves_0',['numberofmoves',['../class_board.html#aff1105359b495049a8dba2b526fc9c5e',1,'Board']]]
];

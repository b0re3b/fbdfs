var searchData=
[
  ['playertype_0',['PlayerType',['../class_player.html#a97dc3c423902370176605121e8f68415',1,'Player']]]
];

var searchData=
[
  ['bestmove_0',['BestMove',['../class_board.html#a28e473dd18ef2b393c37104bd4c82806',1,'Board']]],
  ['board_1',['Board',['../class_board.html#ad5b157608f1afb42a279ff4618f1746b',1,'Board']]]
];

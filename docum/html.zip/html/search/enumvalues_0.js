var searchData=
[
  ['computer_0',['Computer',['../class_player.html#a97dc3c423902370176605121e8f68415a181900dad960beccb34f53c4e0ff4647',1,'Player']]]
];

var searchData=
[
  ['highlight_0',['highlight',['../class_board.html#a790e366fefe939f72e67210d60119850',1,'Board']]],
  ['how_20it_20works_1',['How It Works',['../index.html#autotoc_md10',1,'']]],
  ['human_2',['Human',['../class_player.html#a97dc3c423902370176605121e8f68415ac1bb19b27818343c1926119b958741b5',1,'Player']]],
  ['humanplayer_3',['humanPlayer',['../class_game.html#a747a458871d587d8544ab222b4dedfa5',1,'Game::humanPlayer'],['../class_player_test.html#a7acb3984e75c711b8960b177caa6b082',1,'PlayerTest::humanPlayer']]]
];

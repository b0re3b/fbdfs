var searchData=
[
  ['pieces_0',['pieces',['../class_board.html#a390535e7cc8ea9aa2f994161476dff5a',1,'Board']]]
];

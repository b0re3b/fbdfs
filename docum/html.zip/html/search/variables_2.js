var searchData=
[
  ['depth_0',['depth',['../class_board.html#a6042c62445c706f644893d98836cf535',1,'Board']]]
];

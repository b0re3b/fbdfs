var searchData=
[
  ['isalive_0',['isAlive',['../class_piece.html#a2706790c861fa4181f55f742d50ed105',1,'Piece']]],
  ['isking_1',['isKing',['../class_piece.html#a98ddd530a5ffb3ee8242dc5b986aa3c5',1,'Piece']]]
];

var searchData=
[
  ['idk_2emd_0',['idk.md',['../idk_8md.html',1,'']]]
];

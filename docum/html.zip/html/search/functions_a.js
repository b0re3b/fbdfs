var searchData=
[
  ['opponentpiece_0',['opponentPiece',['../class_board.html#abbe30916d4a4d9b9ef300c1265c4f1f2',1,'Board']]]
];

var searchData=
[
  ['idk_2emd_0',['idk.md',['../idk_8md.html',1,'']]],
  ['initializegame_1',['InitializeGame',['../class_board.html#a61dfb82c7d38f13f13bbb10a5dfdc0f2',1,'Board']]],
  ['inputdata_2',['inputdata',['../class_board.html#ae0c1ec088b9664312550a2e6091c56a0',1,'Board']]],
  ['interaction_20overview_20diagram_3',['Interaction Overview diagram',['../index.html#autotoc_md23',1,'']]],
  ['isalive_4',['isAlive',['../class_piece.html#a2706790c861fa4181f55f742d50ed105',1,'Piece']]],
  ['isking_5',['isKing',['../class_piece.html#a98ddd530a5ffb3ee8242dc5b986aa3c5',1,'Piece']]],
  ['ispieceat_6',['isPieceAt',['../class_board.html#a33d07c0a5b365d84bbd673c9df5ed74f',1,'Board']]],
  ['it_20works_7',['How It Works',['../index.html#autotoc_md10',1,'']]]
];

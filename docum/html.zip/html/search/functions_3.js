var searchData=
[
  ['draw_0',['draw',['../class_board.html#a1fa67ca04a50dc4a17428848413b1549',1,'Board']]],
  ['draw_1',['Draw',['../class_piece.html#a9f95b8ff5068a8a2cd8c5476e5692462',1,'Piece']]]
];

var searchData=
[
  ['type_0',['type',['../class_player.html#a06e4a3eec737ef284f7ae42a60c0967f',1,'Player']]]
];

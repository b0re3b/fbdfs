var searchData=
[
  ['test_0',['TEST',['../testproject_8cpp.html#aec24092c110b40b533c256e7e86e8396',1,'TEST(MoveNodeTest, ConstructorTest):&#160;testproject.cpp'],['../testproject_8cpp.html#abc85f6cbf0dfb5a6fd4bc4715ed0df7b',1,'TEST(PlayerTest, ConstructorTest):&#160;testproject.cpp'],['../testproject_8cpp.html#ac673627aa551b3e6382c6ca7101fba5a',1,'TEST(MenuTest, ChooseColorTest):&#160;testproject.cpp'],['../testproject_8cpp.html#a77ec9a72b232b7e4d4157164e7500d1e',1,'TEST(BoardTest, MinimaxTest):&#160;testproject.cpp'],['../testproject_8cpp.html#ab70321bfa59d7097d1948089d167edab',1,'TEST(BoardTest, EvaluateBoardTest):&#160;testproject.cpp'],['../testproject_8cpp.html#aab50f1478f51fdca1adff33b9a11e373',1,'TEST(BoardTest, ValidarityTest):&#160;testproject.cpp']]],
  ['test_5ff_1',['TEST_F',['../testproject_8cpp.html#a4a117eb58e7857d12c5210dee7786fe5',1,'TEST_F(MoveNodeTest, AddChildTest):&#160;testproject.cpp'],['../testproject_8cpp.html#affb123fc95d283a5d4e50441a701cc6c',1,'TEST_F(PlayerTest, GetColorTest):&#160;testproject.cpp']]],
  ['testing_2',['Testing',['../index.html#autotoc_md12',1,'']]],
  ['testproject_2ecpp_3',['testproject.cpp',['../testproject_8cpp.html',1,'']]],
  ['type_4',['type',['../class_player.html#a06e4a3eec737ef284f7ae42a60c0967f',1,'Player']]]
];

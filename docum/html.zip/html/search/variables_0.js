var searchData=
[
  ['blackplayer_0',['blackPlayer',['../class_board.html#ae1fed3907b87eb89f81794344410509b',1,'Board']]],
  ['board_1',['board',['../class_game.html#af5bc546b0c766ecf2f7e008f750832ed',1,'Game::board'],['../class_board_test.html#abf0eb4c1748799e256ea8f9e49861339',1,'BoardTest::board']]]
];

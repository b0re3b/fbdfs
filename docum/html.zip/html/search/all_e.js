var searchData=
[
  ['redplayer_0',['redPlayer',['../class_board.html#a5b740b84119ba36008624b0ed5168343',1,'Board']]],
  ['run_1',['run',['../class_game.html#a1ab78f5ed0d5ea879157357cf2fb2afa',1,'Game']]],
  ['running_2',['Building and Running',['../index.html#autotoc_md11',1,'']]]
];

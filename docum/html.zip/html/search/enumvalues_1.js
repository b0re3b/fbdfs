var searchData=
[
  ['human_0',['Human',['../class_player.html#a97dc3c423902370176605121e8f68415ac1bb19b27818343c1926119b958741b5',1,'Player']]]
];

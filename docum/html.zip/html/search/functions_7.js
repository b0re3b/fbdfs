var searchData=
[
  ['initializegame_0',['InitializeGame',['../class_board.html#a61dfb82c7d38f13f13bbb10a5dfdc0f2',1,'Board']]],
  ['inputdata_1',['inputdata',['../class_board.html#ae0c1ec088b9664312550a2e6091c56a0',1,'Board']]],
  ['ispieceat_2',['isPieceAt',['../class_board.html#a33d07c0a5b365d84bbd673c9df5ed74f',1,'Board']]]
];

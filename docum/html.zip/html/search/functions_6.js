var searchData=
[
  ['highlight_0',['highlight',['../class_board.html#a790e366fefe939f72e67210d60119850',1,'Board']]]
];

var searchData=
[
  ['score_0',['score',['../class_move_node.html#a018c8f66587b8bcc092c0d00910ae9f8',1,'MoveNode']]],
  ['selectedpieceindex_1',['selectedPieceIndex',['../class_board.html#af678b8e49e55b4936f8ccdf7eb516c6d',1,'Board']]],
  ['size_2',['size',['../class_board.html#a1da791ecf6f0f4b67db719b627b2c1ee',1,'Board']]],
  ['startx_3',['startX',['../class_move.html#adffa38920811f46a17dd07be4ce4e82f',1,'Move']]],
  ['starty_4',['startY',['../class_move.html#aa217487271e2eb8fbd87d28af4b08c3c',1,'Move']]]
];

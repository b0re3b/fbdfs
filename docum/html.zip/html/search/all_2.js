var searchData=
[
  ['case_0',['Use case',['../index.html#autotoc_md14',1,'']]],
  ['changes_1',['Changes',['../index.html#autotoc_md25',1,'']]],
  ['checkers_20game_20with_20ai_20uml_20diagrams_2',['Checkers Game with AI UML Diagrams',['../index.html',1,'']]],
  ['children_3',['children',['../class_move_node.html#acd256b8218247eeaf5e37ba99defd8ec',1,'MoveNode']]],
  ['choosecolor_4',['chooseColor',['../class_menu.html#a3d3853ab79d00451eba6f9eb6fca9845',1,'Menu']]],
  ['class_20diagram_5',['Class diagram',['../index.html#autotoc_md15',1,'']]],
  ['color_6',['color',['../class_piece.html#a41c2a748b38cf1e4fe03f6fccf3958e8',1,'Piece::color'],['../class_player.html#a3e11cd01a03f62f8295ec78e8aa855df',1,'Player::color']]],
  ['component_20diagram_7',['Component diagram',['../index.html#autotoc_md16',1,'']]],
  ['components_8',['Components',['../index.html#autotoc_md1',1,'']]],
  ['composite_20structure_9',['Composite Structure',['../index.html#autotoc_md18',1,'']]],
  ['computer_10',['Computer',['../class_player.html#a97dc3c423902370176605121e8f68415a181900dad960beccb34f53c4e0ff4647',1,'Player']]],
  ['computermove_11',['ComputerMove',['../class_board.html#a1d8ab6546df5c6f29d91daf37827990e',1,'Board']]],
  ['computerplayer_12',['computerPlayer',['../class_game.html#abaf753fdf7bba5de3e126be09259c38e',1,'Game']]]
];

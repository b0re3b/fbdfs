var searchData=
[
  ['x_0',['x',['../class_piece.html#a895b6803ce74fe8574d6168d66ac6bb5',1,'Piece']]]
];

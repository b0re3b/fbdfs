var searchData=
[
  ['logic_0',['logic',['../classlogic.html',1,'']]]
];

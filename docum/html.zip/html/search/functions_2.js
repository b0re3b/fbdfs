var searchData=
[
  ['choosecolor_0',['chooseColor',['../class_menu.html#a3d3853ab79d00451eba6f9eb6fca9845',1,'Menu']]],
  ['computermove_1',['ComputerMove',['../class_board.html#a1d8ab6546df5c6f29d91daf37827990e',1,'Board']]]
];

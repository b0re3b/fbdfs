var searchData=
[
  ['piece_0',['Piece',['../class_piece.html#ac57de5803bbad829b143bc7268267dc1',1,'Piece']]],
  ['player_1',['Player',['../class_player.html#aaae88a768d53a2c960f973b7aefff5b4',1,'Player::Player(const sf::Color color)'],['../class_player.html#a9ceaaf5c4f494db523411bdcaf781189',1,'Player::Player(sf::Color color, PlayerType type)']]]
];

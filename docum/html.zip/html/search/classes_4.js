var searchData=
[
  ['piece_0',['Piece',['../class_piece.html',1,'']]],
  ['player_1',['Player',['../class_player.html',1,'']]],
  ['playertest_2',['PlayerTest',['../class_player_test.html',1,'']]]
];

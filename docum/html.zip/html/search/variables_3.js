var searchData=
[
  ['endx_0',['endX',['../class_move.html#a1c557dde425b7624f0ca7e6e7f33baa5',1,'Move']]],
  ['endy_1',['endY',['../class_move.html#a1223cbd38258e9b08f977ea6670f1357',1,'Move']]]
];

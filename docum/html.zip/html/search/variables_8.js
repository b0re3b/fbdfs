var searchData=
[
  ['redplayer_0',['redPlayer',['../class_board.html#a5b740b84119ba36008624b0ed5168343',1,'Board']]]
];

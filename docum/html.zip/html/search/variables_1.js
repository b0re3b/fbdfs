var searchData=
[
  ['children_0',['children',['../class_move_node.html#acd256b8218247eeaf5e37ba99defd8ec',1,'MoveNode']]],
  ['color_1',['color',['../class_piece.html#a41c2a748b38cf1e4fe03f6fccf3958e8',1,'Piece::color'],['../class_player.html#a3e11cd01a03f62f8295ec78e8aa855df',1,'Player::color']]],
  ['computerplayer_2',['computerPlayer',['../class_game.html#abaf753fdf7bba5de3e126be09259c38e',1,'Game']]]
];

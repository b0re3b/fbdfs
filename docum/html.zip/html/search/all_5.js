var searchData=
[
  ['game_0',['Game',['../class_game.html',1,'Game'],['../class_game.html#ad2552ce8878861f03865debbfb7f3fa4',1,'Game::Game()'],['../index.html#autotoc_md9',1,'Game']]],
  ['game_20with_20ai_20uml_20diagrams_1',['Checkers Game with AI UML Diagrams',['../index.html',1,'']]],
  ['gameloop_2ecpp_2',['gameloop.cpp',['../gameloop_8cpp.html',1,'']]],
  ['gameloop_2eh_3',['gameloop.h',['../gameloop_8h.html',1,'']]],
  ['generatemoves_4',['generateMoves',['../class_board.html#adac5a66fac8459a9ed625ecabd42614d',1,'Board']]],
  ['getblackplayer_5',['getBlackPlayer',['../class_board.html#a68790756b7e024ebbc9dde1dd23680ed',1,'Board']]],
  ['getchildren_6',['getChildren',['../class_move_node.html#a9740407daa34fcadcd18073ba87a38f4',1,'MoveNode']]],
  ['getcolor_7',['getColor',['../class_player.html#a6af84629a95779c478adcd24efcefb1b',1,'Player']]],
  ['getendx_8',['getEndX',['../class_move.html#a2d670ad83efcfd894e7877252fce69de',1,'Move']]],
  ['getendy_9',['getEndY',['../class_move.html#a3b5509b1d995526c851561f73d327ff3',1,'Move']]],
  ['getmove_10',['getMove',['../class_move_node.html#a2c4d21bd5922de5c2f66a45abc2a5ca9',1,'MoveNode']]],
  ['getredplayer_11',['getRedPlayer',['../class_board.html#a026fa9718ec3e11d9dbc14135dc8bc8b',1,'Board']]],
  ['getscore_12',['getScore',['../class_move_node.html#ac6be6277905b2d5887ca4c1c151f64f7',1,'MoveNode']]],
  ['getstartx_13',['getStartX',['../class_move.html#ae5b75e6f1d977e5eacac7e85d991ed27',1,'Move']]],
  ['getstarty_14',['getStartY',['../class_move.html#afb1961349a3fb940e4596ee12d28cf1f',1,'Move']]]
];

var searchData=
[
  ['humanplayer_0',['humanPlayer',['../class_game.html#a747a458871d587d8544ab222b4dedfa5',1,'Game::humanPlayer'],['../class_player_test.html#a7acb3984e75c711b8960b177caa6b082',1,'PlayerTest::humanPlayer']]]
];

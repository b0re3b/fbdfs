var searchData=
[
  ['ai_20uml_20diagrams_0',['Checkers Game with AI UML Diagrams',['../index.html',1,'']]]
];
